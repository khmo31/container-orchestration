# Manifest Schema

각 컨테이너/에이전트는 `manifest.json`을 가진다.
이는 dispatcher가 코드 기반으로 라우팅 결정을 내릴 때 사용하는 **자기소개서**다.

## Schema

```json
{
  "schema_version": "1.0",
  "agent_id": "hermes",
  "name": "Hermes",
  "version": "1.0.0",
  "description": "짧은 설명",
  "endpoint": {
    "type": "http|docker_exec",
    "url": "http://...",
    "health_check": "http://..."
  },
  "capabilities": ["array", "of", "strings"],
  "dependencies": [],
  "maintainer": "hermes",
  "created": "2026-05-20",
  "updated": "2026-05-20"
}
```

## Fields

| 필드 | 필수 | 설명 |
|------|------|------|
| `agent_id` | ✅ | 고유 식별자. registry.json과 일치 |
| `name` | ✅ | 사람이 읽을 수 있는 이름 |
| `version` | ✅ | 시맨틱 버전 |
| `description` | ✅ | 이 에이전트가 무엇을 하는지 |
| `endpoint.type` | ✅ | `http` 또는 `docker_exec` |
| `endpoint.url` | ✅ | 호출 주소 (http: URL, docker_exec: container name) |
| `capabilities` | ✅ | 이 에이전트가 할 수 있는 일들 |
| `maintainer` | - | 관리 주체 (보통 `hermes`) |

## 관리

- 최초 작성: Hermes (컨테이너 발견/등록 시)
- 업데이트: Hermes (capability 변경, 버전 업 시)
- 읽기: Dispatcher (라우팅 결정 시)
- 보관 위치: `dispatcher/manifests/{agent_id}.json`
