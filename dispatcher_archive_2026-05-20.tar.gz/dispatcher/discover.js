#!/usr/bin/env node

/**
 * discover.js — Container Auto-Discovery Pipeline
 *
 * 하트비트 시점에 실행:
 * 1. docker ps 스캔 → 새로운 컨테이너 발견
 * 2. Hermes에 분석 의뢰 → capability, 설명 추론
 * 3. manifest.json 생성
 * 4. registry.json 등록 (manifest-sync)
 * 5. policy.json 검토
 * 6. TOOLS.md 업데이트
 * 7. khmo에게 보고
 *
 * 사용법:
 *   node discover.js              ← 모든 발견 및 등록
 *   node discover.js --scan-only  ← 스캔만 (등록 안 함)
 *   node discover.js --dry-run    ← 스캔 + Hermes 분석까지, 등록 제외
 *   node discover.js --force <id> ← 특정 컨테이너 강제 등록
 */

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const DISPATCHER_DIR = path.dirname(__dirname); // .../dispatcher/
const MANIFESTS_DIR = path.join(DISPATCHER_DIR, 'manifests');
const REGISTRY_PATH = path.join(DISPATCHER_DIR, 'registry.json');
const POLICY_PATH = path.join(DISPATCHER_DIR, 'policy.json');

// 알려진 컨테이너 (manifest.json이 이미 있는 것)
const KNOWN_CONTAINERS = new Set([
  'hermes', 'aifactory-metagpt', 'aifactory-ejclaw',
  'aifactory-opencode', 'auto-trading'
]);

// 알려진 이미지 (같은 이미지로 생성된 다른 이름의 컨테이너는 무시)
const KNOWN_IMAGES = new Set([
  'aifactory-opencode', 'aifactory-metagpt', 'aifactory-ejclaw',
  'auto-trading-pipeline', 'hermes'
]);

// 무시할 컨테이너 패턴 (Docker 내부 시스템)
const IGNORE_PATTERNS = [
  /^docker/, /^kube/, /^registry/, /^mysql/, /^redis/,
  /^postgres/, /^minio/, /^traefik/, /^nginx/
];

function log(msg) {
  console.log(`[discover] ${msg}`);
}

function getRunningContainers() {
  const output = execSync('docker ps --format "{{.Names}}"', {
    timeout: 10000,
    encoding: 'utf-8'
  }).trim();
  return output ? output.split('\n') : [];
}

function getExistingManifests() {
  if (!fs.existsSync(MANIFESTS_DIR)) return new Set();
  return new Set(
    fs.readdirSync(MANIFESTS_DIR)
      .filter(f => f.endsWith('.json') && f !== 'MANIFEST_SCHEMA.md')
      .map(f => f.replace('.json', ''))
  );
}

function getExistingRegistryAgents() {
  const raw = JSON.parse(fs.readFileSync(REGISTRY_PATH, 'utf-8'));
  return new Set(Object.keys(raw.agents));
}

function shouldIgnore(name) {
  if (KNOWN_CONTAINERS.has(name)) return true;
  if (IGNORE_PATTERNS.some(p => p.test(name))) return true;

  // Check by image name (catch duplicates)
  try {
    const image = execSync(
      `docker inspect ${name} --format '{{.Config.Image}}' 2>/dev/null`,
      { timeout: 3000, encoding: 'utf-8' }
    ).trim();
    // Extract image name without tag
    const imageName = image.split(':')[0];
    if (KNOWN_IMAGES.has(imageName)) return true;
  } catch {}

  return false;
}

async function askHermes(containerName) {
  const http = require('http');
  const payload = JSON.stringify({
    message: `[Container Discovery] New container detected: "${containerName}"

Please analyze this container and provide:
1. What is this container likely doing? (based on its name)
2. What capabilities would it have? (array of strings)
3. What endpoint type would it use? (http or docker_exec)
4. A short description (1 sentence)

Respond with a JSON object only:
{
  "name": "Human readable name",
  "description": "Short description",
  "capabilities": ["cap1", "cap2"],
  "endpoint_type": "docker_exec",
  "container": "${containerName}"
}` });

  return new Promise((resolve) => {
    const req = http.request({
      hostname: 'localhost',
      port: 8000,
      path: '/chat',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      },
      timeout: 60000
    }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          const text = parsed.reply || parsed.response || '';
          // Try to extract JSON from Hermes's response
          const jsonMatch = text.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            resolve(JSON.parse(jsonMatch[0]));
          } else {
            resolve({
              name: containerName.replace(/^aifactory-/, ''),
              description: 'Auto-discovered container',
              capabilities: ['unknown'],
              endpoint_type: 'docker_exec',
              container: containerName
            });
          }
        } catch {
          resolve({
            name: containerName.replace(/^aifactory-/, ''),
            description: 'Auto-discovered container',
            capabilities: ['unknown'],
            endpoint_type: 'docker_exec',
            container: containerName
          });
        }
      });
    });
    req.on('error', (e) => {
      log(`Hermes analysis failed: ${e.message}, using defaults`);
      resolve({
        name: containerName.replace(/^aifactory-/, ''),
        description: 'Auto-discovered container',
        capabilities: ['unknown'],
        endpoint_type: 'docker_exec',
        container: containerName
      });
    });
    req.on('timeout', () => {
      req.destroy();
      log('Hermes analysis timed out, using defaults');
      resolve({
        name: containerName.replace(/^aifactory-/, ''),
        description: 'Auto-discovered container',
        capabilities: ['unknown'],
        endpoint_type: 'docker_exec',
        container: containerName
      });
    });
    req.write(payload);
    req.end();
  });
}

async function discover(dryRun = false, forceContainer = null) {
  log('Starting container discovery...');

  const containers = getRunningContainers();
  log(`Found ${containers.length} running containers`);

  const existing = getExistingManifests();
  const newlyDiscovered = [];

  for (const name of containers) {
    if (shouldIgnore(name)) {
      log(`→ ${name}: already known (skipping)`);
      continue;
    }
    if (forceContainer && name !== forceContainer) continue;

    const agentId = name.replace(/^aifactory-/, '').replace(/[^a-zA-Z0-9_-]/g, '_');
    
    if (existing.has(agentId) && !forceContainer) {
      log(`→ ${name}: manifest already exists (skipping)`);
      continue;
    }

    log(`→ NEW: ${name} (agent_id: ${agentId})`);
    newlyDiscovered.push({ name, agentId });
  }

  if (newlyDiscovered.length === 0) {
    log('No new containers found.');
    return [];
  }

  const results = [];

  for (const { name, agentId } of newlyDiscovered) {
    log(`  Analyzing ${name} via Hermes...`);
    
    let info;
    try {
      info = await askHermes(name);
    } catch {
      info = {
        name: agentId,
        description: 'Auto-discovered container',
        capabilities: ['unknown'],
        endpoint_type: 'docker_exec',
        container: name
      };
    }

    const manifest = {
      schema_version: '1.0',
      agent_id: agentId,
      name: info.name || agentId,
      version: '1.0.0',
      description: info.description || 'Auto-discovered container',
      endpoint: {
        type: info.endpoint_type || 'docker_exec',
        container: name,
        workdir: '/app',
        shell: '/bin/bash'
      },
      capabilities: info.capabilities || ['unknown'],
      dependencies: [],
      maintainer: 'hermes',
      created: new Date().toISOString().slice(0, 10),
      updated: new Date().toISOString().slice(0, 10)
    };

    results.push({ agentId, name, manifest });

    if (dryRun) {
      log(`  [DRY RUN] Would create manifest for ${name}:`);
      log(`    ${JSON.stringify(manifest, null, 4)}`);
    } else {
      // Write manifest
      fs.writeFileSync(
        path.join(MANIFESTS_DIR, `${agentId}.json`),
        JSON.stringify(manifest, null, 2)
      );
      log(`  ✅ manifest created: manifests/${agentId}.json`);
    }
  }

  return results;
}

function report(results) {
  if (results.length === 0) return;
  
  console.log('\n=== Discovery Report ===');
  console.log(`New containers registered: ${results.length}\n`);
  
  for (const { agentId, name, manifest } of results) {
    console.log(`  📦 ${name} (${agentId})`);
    console.log(`     ${manifest.description}`);
    console.log(`     Capabilities: ${(manifest.capabilities || []).join(', ')}`);
    console.log('');
  }
}

async function main() {
  const args = process.argv.slice(2);

  if (args.includes('--help') || args.includes('-h')) {
    console.log(`
Container Auto-Discovery Pipeline

Usage:
  node discover.js                  Full discovery + registration
  node discover.js --scan-only      Scan only (no changes)
  node discover.js --dry-run        Scan + Hermes analysis, no registration
  node discover.js --force <name>   Force register specific container

This pipeline:
  1. docker ps → find unknown containers
  2. Hermes analysis → infer capabilities
  3. manifest.json creation
  4. (requires: node dispatcher.js --manifest-sync to update registry)
    `);
    process.exit(0);
  }

  const scanOnly = args.includes('--scan-only');
  const dryRun = args.includes('--dry-run') || scanOnly;
  const forceIdx = args.indexOf('--force');
  const forceContainer = forceIdx >= 0 && args.length > forceIdx + 1 ? args[forceIdx + 1] : null;

  const results = await discover(dryRun, forceContainer);

  if (scanOnly) {
    console.log('\nScan complete. To register, run without --scan-only');
    process.exit(0);
  }

  report(results);

  if (!dryRun && results.length > 0) {
    log('Running manifest-sync to update registry...');
    try {
      const syncOutput = execSync(
        `node ${path.join(DISPATCHER_DIR, 'dispatcher.js')} --manifest-sync 2>&1`,
        { timeout: 15000, encoding: 'utf-8' }
      );
      console.log(syncOutput);
    } catch (e) {
      log(`manifest-sync: ${e.message}`);
    }

    log('\n⚠️  Reminder: Check policy.json for new routing rules.');
    log('   Update TOOLS.md with new agent info.');
    log('   Notify khmo about the new container.');
  }

  if (results.length === 0) {
    log('Nothing to do.');
  }
}

if (require.main === module) {
  main().catch(e => {
    console.error('[discover] Fatal:', e.message);
    process.exit(1);
  });
}

module.exports = { discover, getRunningContainers, shouldIgnore };
